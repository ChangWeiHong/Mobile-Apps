package com.example.calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;



public class EventViewActivity extends AppCompatActivity {

    private TextView title, time, location, displaydate;
    private Button deletebtn;
    private ImageButton locationbtn;

    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
        Bundle intent = getIntent().getExtras();
        final String date = intent.getString("date");
        db = FirebaseDatabase.getInstance();
        //assert date != null;
        reference = db.getReference().child("myEvent").child(date);
        title = findViewById(R.id.tv_title);
        time = findViewById(R.id.tv_time);
        displaydate = findViewById(R.id.tv_date);
        location = findViewById(R.id.tv_location);
        deletebtn = findViewById(R.id.delete);
        locationbtn = findViewById(R.id.gpsbtn);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                myEvent event = dataSnapshot.getValue(myEvent.class);
                displaydate.setText(event.getDATE());
                location.setText(event.getLocation());
                time.setText(event.getTime());
                title.setText(event.getTitle());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(EventViewActivity.this, databaseError.getCode(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
