package com.example.calendar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {

    private ListView eventlistview;
    ArrayList arrayList = new ArrayList();
    ArrayAdapter arrayAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        eventlistview = findViewById(R.id.eventlistview);
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);

        Bundle intent = getIntent().getExtras();
        String passeddate = intent.getString("passdate");
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        //DatabaseReference reference = db.getReference().child("myEvent");
        eventlistview.setAdapter(arrayAdapter);
        Query query = db.getReference("myEvent")
                .orderByChild("date").equalTo(passeddate);

        query.addListenerForSingleValueEvent(valueEventListener);


        eventlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {

                //int itemposition = Integer.parseInt(eventlist.getItemAtPosition(i).toString());
                String item = eventlistview.getItemAtPosition(i).toString();
                Intent intent = new Intent(EventListActivity.this, EventViewActivity.class);
                intent.putExtra("view",item);
                startActivity(intent);
            }
        });
        eventlistview.setAdapter(arrayAdapter);
    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            arrayList.clear();
            if(dataSnapshot.exists()){
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                    myEvent values = snapshot.getValue(myEvent.class);
                    arrayList.add(values.getTitle());
                }
                arrayAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };
}
