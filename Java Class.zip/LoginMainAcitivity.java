package com.example.calendar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginMainAcitivity extends AppCompatActivity {
    private Button login;
    private TextView forgetpw, registration,attempts;
    private EditText edemail, edpassword;
    private FirebaseAuth firebaseAuth;
    private int counter = 5;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.button);
        attempts = findViewById(R.id.textView3);
        forgetpw = findViewById(R.id.textView2);
        registration = findViewById(R.id.textView);
        edemail = findViewById(R.id.editText);
        edpassword = findViewById(R.id.editText2);

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);


        attempts.setText("No of attempts remaining: 5");

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(edemail.getText().toString(),edpassword.getText().toString());

            }
        });

        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginMainAcitivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        forgetpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginMainAcitivity.this, ForgetPwActivity.class);
                startActivity(intent);
            }
        });
    }

    private Boolean check(){
        Boolean result = false;
        String emailaddress = edemail.getText().toString();
        String password = edpassword.getText().toString();

        if(emailaddress.isEmpty() || password.isEmpty()){
            Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        }else{
            result = true;
        }

        return result;
    }

    public void validate(String email,String password){
        if(check()){
            progressDialog.setMessage("Logging in...");
            progressDialog.show();

            firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        progressDialog.dismiss();
                        Toast.makeText(LoginMainAcitivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginMainAcitivity.this,AfterLoginActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginMainAcitivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        counter--;
                        attempts.setText("No of attempts remaining: " + counter);
                        progressDialog.dismiss();
                        if(counter == 0){
                            login.setEnabled(false);
                        }
                    }
                }

            });
        }

    }
}
