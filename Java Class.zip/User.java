package com.example.calendar;

public class User {
    private String username,useremail;

    public User() {
    }

    public User(String name, String email){
        this.username = name;
        this.useremail = email;

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }


}
