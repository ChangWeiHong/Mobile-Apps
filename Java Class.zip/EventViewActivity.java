package com.example.calendar;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class EventViewActivity extends AppCompatActivity {

    private TextView title, time, location, displaydate;
    private Button deletebtn;
    private ImageButton locationbtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);

        title = findViewById(R.id.tv_title);
        time = findViewById(R.id.tv_time);
        displaydate = findViewById(R.id.tv_date);
        location = findViewById(R.id.tv_location);
        deletebtn = findViewById(R.id.delete);
        locationbtn = findViewById(R.id.gpsbtn);
        FirebaseDatabase db;
        DatabaseReference reference;
        Bundle intent = getIntent().getExtras();
        assert intent != null;
        final String title = intent.getString("view");
        db = FirebaseDatabase.getInstance();
        //assert date != null;
        //reference = db.getReference().child("myEvent");
        Query query = db.getReference("myEvent")
                .orderByChild("title").equalTo(title);

        query.addListenerForSingleValueEvent(valueEventListener);


        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Bundle intent = getIntent().getExtras();
                //assert intent != null;
                // final String titlefordelete = intent.getString("view");

                Query delete = FirebaseDatabase.getInstance().getReference("myEvent")
                        .orderByChild("title").equalTo(title);

                delete.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded( DataSnapshot dataSnapshot, String previousChild) {
                        dataSnapshot.getRef().setValue(null);
                        Toast.makeText(EventViewActivity.this,"Event deleted.",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(EventViewActivity.this,ForCalendar.class));
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                //.addOnCompleteListener(new OnCompleteListener<Void>() {
                //@Override
                // public void onComplete(@NonNull Task<Void> task) {
                //Intent intent = new Intent(EventViewActivity.this,CustomCalendarView.class);
                //startActivity(intent);
                //didnotToast
                //Toast.makeText(EventViewActivity.this,"Event Deleted.",Toast.LENGTH_SHORT).show();
                // }
                //  });
            }
        });

    }
    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if (dataSnapshot.exists()) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    final myEvent event = snapshot.getValue(myEvent.class);

                    if (event != null) {
                        displaydate.setText(event.getDATE());
                        location.setText(event.getLocation());
                        time.setText(event.getTime());
                        title.setText(event.getTitle());

                        locationbtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {


                                String locationsearch = event.getLocation();
                                Intent intent3 = new Intent(EventViewActivity.this, MapsActivity.class);
                                intent3.putExtra("locationsearch", locationsearch);
                                startActivity(intent3);
                            }
                        });
                    } else {
                        //error
                        Toast.makeText(EventViewActivity.this, "No Event Added.", Toast.LENGTH_SHORT).show();
                        Intent add = new Intent(EventViewActivity.this, MainActivity.class);
                        startActivity(add);
                        //error
                    }
                }

            }

        }
        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            Toast.makeText(EventViewActivity.this, databaseError.getCode(), Toast.LENGTH_LONG).show();
        }
    };
}