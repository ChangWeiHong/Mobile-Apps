package com.example.calendar;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private Button register;
    private TextView login;
    private EditText edname, edenteremail, edpw;
    private FirebaseAuth firebaseAuth;
    private String name, email, pw, cpw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        register = findViewById(R.id.button2);
        login = findViewById(R.id.textView4);
        edname = findViewById(R.id.editText3);
        edenteremail = findViewById(R.id.editText4);
        edpw = findViewById(R.id.editText5);
        firebaseAuth = FirebaseAuth.getInstance();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(check()){
                    //Upload data to the database
                    String user_email = edenteremail.getText().toString().trim();
                    String user_password = edpw.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email,user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task. isSuccessful()){
                                saveUserData();
                                Toast.makeText(RegisterActivity.this,"Registration is successful.",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                                finish();
                                startActivity(intent);
                            }else{
                                checkConnection();
                            }
                        }
                    });

                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private Boolean check(){
        Boolean result = false;

        name = edname.getText().toString();
        email = edenteremail.getText().toString();
        pw = edpw.getText().toString();



        if(name.isEmpty() || email.isEmpty() || pw.isEmpty() ){
            Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        }else{
            pwlength();
            result = true;
        }

        return result;
    }

    public void pwlength(){
        String pass = edpw.getText().toString();
        if(TextUtils.isEmpty(pass) || pass.length() < 6){
            edpw.setError("You must have 6 characters in your password");
            return;
        }
    }

    private void saveUserData(){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("User");
        User user = new User(edname.getText().toString(), edenteremail.getText().toString());

        user.setUsername(edname.getText().toString());
        user.setUseremail(edenteremail.getText().toString());


        ref.child(firebaseAuth.getUid()).setValue(user);
    }

    private void checkConnection() {
        ConnectivityManager manager = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = manager.getActiveNetworkInfo();
        if(activeNetwork == null)
        {
            Toast.makeText(this, "No Internet Connection!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(RegisterActivity.this, "Registration is unsuccessful!", Toast.LENGTH_SHORT).show();
        }
    }
}
