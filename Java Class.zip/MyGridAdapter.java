package com.example.calendar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Queue;

public class MyGridAdapter extends ArrayAdapter {
    List<Date> dates;
    Calendar currentDate;
    List<myEvent> events;
    LayoutInflater inflater;

    FirebaseDatabase db;
    DatabaseReference reference;
    DataSnapshot dataSnapshot;



    public MyGridAdapter(@NonNull Context context, List<Date> dates, Calendar currentDate, List<myEvent> events) {
        super(context, R.layout.single_cell_layout);
        this.dates=dates;
        this.currentDate=currentDate;
        this.events=events;
        inflater = LayoutInflater.from(context);


    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Date monthDate = dates.get(position);
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(monthDate);
        int DayNo = dateCalendar.get(Calendar.DAY_OF_MONTH);
        int displayMonth = dateCalendar.get(Calendar.MONTH)+1;
        int displayYear = dateCalendar.get(Calendar.YEAR);
        int currentMonth = currentDate.get(Calendar.MONTH)+1;
        int currentYear = currentDate.get(Calendar.YEAR);

        View view = convertView;
        if ( view == null ){
            view = inflater.inflate(R.layout.single_cell_layout, parent,false);

        }

        if (displayMonth == currentMonth && displayYear == currentYear){
            view.setBackgroundColor(getContext().getResources().getColor(R.color.green));
        }
        else {
            view.setBackgroundColor(Color.parseColor("#CCCCCC"));
        }

        if (currentDate == dateCalendar){
            view.setBackgroundColor(Color.parseColor("#056608"));

        }

        TextView Day_Number = view.findViewById(R.id.calendar_day);
        final TextView Event_Number = view.findViewById(R.id.events_id);
        Day_Number.setText(String.valueOf(DayNo));
        Calendar eventCalendar = Calendar.getInstance();
        ArrayList<String> arrList = new ArrayList<>();
        //Event_Number.setText("2");



        SimpleDateFormat eventDateFormat =  new SimpleDateFormat("ddMMMMyyyy",Locale.ENGLISH);
        final String date = eventDateFormat.format(dates.get(position));
        db = FirebaseDatabase.getInstance();
        Query query  = db.getReference().child("myEvent").orderByChild("date").equalTo(date);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                    final myEvent event = snapshot.getValue(myEvent.class);
                    if (event != null){
                        Event_Number.setText("*");
                    }
                }

                //else{                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        //if (event != null){

        //}

        for (int i = 0;i< events.size();i++){
            eventCalendar.setTime(ConvertStringToDate(events.get(i).getDATE()));
            if (DayNo == eventCalendar.get(Calendar.DAY_OF_MONTH)&&displayMonth == eventCalendar.get(Calendar.MONTH)
            && displayYear == eventCalendar.get(Calendar.YEAR)){
                arrList.add(events.get(i).getTitle());
                Event_Number.setText(arrList.size() + "Events");
            }
        }



        return view;
    }


    private Date ConvertStringToDate(String eventDate){
        SimpleDateFormat format = new SimpleDateFormat("ddMMMyyyy", Locale.ENGLISH);
        Date date = null;
        try{
            date = format.parse(eventDate);
        }catch (ParseException e){
            e.printStackTrace();
        }
        return date;
    }

    @Override
    public int getCount() {
        return dates.size();
    }

    @Override
    public int getPosition(@Nullable Object item) {
        return dates.indexOf(item);
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return dates.get(position);
    }
}
